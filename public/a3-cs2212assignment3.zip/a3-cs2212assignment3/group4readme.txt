The following cases are ready to test.

NOTE: The assignment said to use '4.c.?' notation, but I'm assuming it's okay to include working parts from other subsections as well, other than subsection c.

4.c.1.1
4.c.1.2
4.c.2
	- Note: As of right now once you add a child you won't see the updated list until you re-sign in (that is, go to Settings in the top right and then enter your password again)
4.c.4
	- The above note also applies to removing a child
4.c.5
	- Use the update button
4.c.6
	- Settings -> Child Settings -> View Progress
	- Works, but isn't updated by the drill game yet and thus contains no data
4.c.7 
	- Updates the database but currently doesn't have an effect on drill mode
4.c.8
	- Updates the database but currently doesn't have an effect on drill mode
4.c.10
	- Updates the database but currently doesn't have an effect on drill mode
4.c.11
	- Settings -> Level Settings -> Toggle 'Testing mode' on or off
	
4.d.2
4.d.3.2
	- The game ends if the time limit is reached
4.d.3.3
	- Re-adds questions that the child got incorrect to the question pool
 
4.e.2
	- There is a final game and it does keep a score, but it currently has no time limit and no end state and is unlocked from the start

 